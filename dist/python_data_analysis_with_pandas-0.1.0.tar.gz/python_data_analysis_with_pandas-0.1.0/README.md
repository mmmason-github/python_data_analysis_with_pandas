# Python Data Analysis with Pandas
## Set of notebooks of exploring data analysis in python
